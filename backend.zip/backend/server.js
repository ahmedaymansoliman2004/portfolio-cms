/**
 * ================================================================
 *  Ahmed Portfolio CMS — Express.js Backend (Node.js)
 *  Stack: Node 20 · Express 4 · @supabase/supabase-js · JWT
 * ================================================================
 *
 *  Install:
 *    npm init -y
 *    npm i express cors dotenv jsonwebtoken @supabase/supabase-js
 *    npm i -D nodemon
 *
 *  .env file:
 *    SUPABASE_URL=https://xxxx.supabase.co
 *    SUPABASE_SERVICE_KEY=eyJhb...    (service_role key — keep secret!)
 *    JWT_SECRET=your_random_64_char_secret
 *    ADMIN_PASSWORD=your_strong_password   (hash in production!)
 *    PORT=4000
 */

import express    from 'express';
import cors       from 'cors';
import jwt        from 'jsonwebtoken';
import { createClient } from '@supabase/supabase-js';
import 'dotenv/config';

const app = express();
const PORT = process.env.PORT || 4000;

// ── Supabase client (service role — bypasses RLS) ────────────────
const sb = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// ── Middleware ───────────────────────────────────────────────────
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());

// ── JWT Auth Middleware ──────────────────────────────────────────
function requireAuth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// ── AUTHENTICATION ───────────────────────────────────────────────
app.post('/api/auth/login', (req, res) => {
  const { password } = req.body;
  // In production: hash the password with bcrypt
  if (password !== process.env.ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const token = jwt.sign({ role: 'admin' }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

app.post('/api/auth/logout', requireAuth, (req, res) => {
  // JWT is stateless — client just discards the token
  res.json({ success: true });
});

// ── GENERIC CRUD FACTORY ─────────────────────────────────────────
function crudRoutes(router, tableName, publicSelect = '*') {
  // GET all (public)
  router.get('/', async (req, res) => {
    const { data, error } = await sb.from(tableName).select(publicSelect).order('id');
    if (error) return res.status(500).json({ error: error.message });
    res.json(data);
  });

  // GET one (public)
  router.get('/:id', async (req, res) => {
    const { data, error } = await sb.from(tableName).select('*').eq('id', req.params.id).single();
    if (error) return res.status(404).json({ error: 'Not found' });
    res.json(data);
  });

  // POST create (protected)
  router.post('/', requireAuth, async (req, res) => {
    const { data, error } = await sb.from(tableName).insert(req.body).select().single();
    if (error) return res.status(400).json({ error: error.message });
    res.status(201).json(data);
  });

  // PUT update (protected)
  router.put('/:id', requireAuth, async (req, res) => {
    const { data, error } = await sb.from(tableName).update(req.body).eq('id', req.params.id).select().single();
    if (error) return res.status(400).json({ error: error.message });
    res.json(data);
  });

  // DELETE (protected)
  router.delete('/:id', requireAuth, async (req, res) => {
    const { error } = await sb.from(tableName).delete().eq('id', req.params.id);
    if (error) return res.status(400).json({ error: error.message });
    res.json({ success: true });
  });

  return router;
}

// ── ABOUT (single-row special case) ─────────────────────────────
app.get('/api/about', async (req, res) => {
  const { data, error } = await sb.from('about').select('*').single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.put('/api/about', requireAuth, async (req, res) => {
  const { data, error } = await sb.from('about').update(req.body).eq('id', 1).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// ── SECTION ROUTES ───────────────────────────────────────────────
const sections = [
  'skills',
  'projects',
  'experience',
  'reviews',
  'recommendations',
  'certificates',
  'links',
  'social',
  'contact',
];

sections.forEach(section => {
  const router = express.Router();
  crudRoutes(router, section);
  app.use(`/api/${section}`, router);
});

// ── HEALTH CHECK ─────────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date() }));

// ── START ─────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`Portfolio CMS API running on http://localhost:${PORT}`);
});
